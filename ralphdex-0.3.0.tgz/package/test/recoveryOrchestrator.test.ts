import assert from 'node:assert/strict';
import * as fs from 'node:fs/promises';
import * as os from 'node:os';
import * as path from 'node:path';
import test from 'node:test';
import type { FailureAnalysis } from '../src/ralph/failureDiagnostics';
import {
  dispatchRecovery,
  getRecoveryStatePath,
  getSystemicAlertPath,
  type RecoveryContext,
  type SystemicFailureAlert
} from '../src/ralph/recoveryOrchestrator';
import { readDeadLetterQueue, type DeadLetterEntry } from '../src/ralph/deadLetter';

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function makeAnalysis(override: Partial<FailureAnalysis> = {}): FailureAnalysis {
  return {
    schemaVersion: 1,
    kind: 'failureAnalysis',
    taskId: 'T1',
    createdAt: new Date().toISOString(),
    rootCauseCategory: 'transient',
    confidence: 'high',
    summary: 'Test failure.',
    suggestedAction: 'Retry.',
    ...override
  };
}

function makeContext(
  artifactRootDir: string,
  override: Partial<RecoveryContext> = {}
): RecoveryContext {
  return {
    taskId: 'T1',
    taskTitle: 'Test Task',
    analysis: makeAnalysis(),
    artifactRootDir,
    maxRecoveryAttempts: 3,
    autoApplyRemediation: ['decompose_task'],
    releaseClaim: async () => {},
    emitOperatorNotification: async () => {},
    ...override
  };
}

// ---------------------------------------------------------------------------
// AC 11: transient failure triggers auto-retry with backoff without LLM call
// ---------------------------------------------------------------------------

test('transient failure returns retry_with_backoff action', async () => {
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'ralph-recovery-'));
  try {
    let releaseClaimCalled = false;
    let notificationEmitted = false;

    const decision = await dispatchRecovery(makeContext(tmpDir, {
      analysis: makeAnalysis({ rootCauseCategory: 'transient' }),
      releaseClaim: async () => { releaseClaimCalled = true; },
      emitOperatorNotification: async () => { notificationEmitted = true; }
    }));

    assert.equal(decision.action, 'retry_with_backoff');
    assert.ok(typeof decision.backoffMs === 'number' && decision.backoffMs > 0, 'backoffMs should be positive');
    assert.equal(decision.pauseAgent, false);
    assert.equal(decision.escalated, false);
    assert.equal(decision.attemptCount, 1);
    // No claim release and no operator notification — transient path is self-contained.
    assert.equal(releaseClaimCalled, false);
    assert.equal(notificationEmitted, false);
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
});

test('transient failure backoff grows exponentially on subsequent attempts', async () => {
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'ralph-recovery-'));
  try {
    const ctx = makeContext(tmpDir, { analysis: makeAnalysis({ rootCauseCategory: 'transient' }) });

    const first = await dispatchRecovery(ctx);
    const second = await dispatchRecovery(ctx);
    const third = await dispatchRecovery(ctx);

    assert.ok(first.backoffMs! < second.backoffMs!, 'backoff should grow on second attempt');
    assert.ok(second.backoffMs! < third.backoffMs!, 'backoff should grow on third attempt');
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
});

test('transient failure attempt count resets when category changes', async () => {
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'ralph-recovery-'));
  try {
    const ctx = makeContext(tmpDir, { analysis: makeAnalysis({ rootCauseCategory: 'transient' }) });

    // Accumulate two transient attempts.
    await dispatchRecovery(ctx);
    await dispatchRecovery(ctx);

    // Now switch to a different category — count should reset to 1.
    const decision = await dispatchRecovery(makeContext(tmpDir, {
      analysis: makeAnalysis({ rootCauseCategory: 'implementation_error' })
    }));
    assert.equal(decision.attemptCount, 1);
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
});

// ---------------------------------------------------------------------------
// AC 12: implementation_error injects retryPromptAddendum into next prompt
// ---------------------------------------------------------------------------

test('implementation_error returns retry_with_addendum with the addendum text', async () => {
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'ralph-recovery-'));
  try {
    const addendum = 'Focus on type safety in the new module.';
    const decision = await dispatchRecovery(makeContext(tmpDir, {
      analysis: makeAnalysis({ rootCauseCategory: 'implementation_error', retryPromptAddendum: addendum }),
      autoApplyRemediation: []
    }));

    assert.equal(decision.action, 'retry_with_addendum');
    assert.equal(decision.retryPromptAddendum, addendum);
    assert.equal(decision.pauseAgent, false);
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
});

test('implementation_error persists retryPromptAddendum in recovery-state.json', async () => {
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'ralph-recovery-'));
  try {
    const addendum = 'Check the return type of processResult.';
    await dispatchRecovery(makeContext(tmpDir, {
      analysis: makeAnalysis({ rootCauseCategory: 'implementation_error', retryPromptAddendum: addendum })
    }));

    const stateText = await fs.readFile(getRecoveryStatePath(tmpDir, 'T1'), 'utf8');
    const state = JSON.parse(stateText);
    assert.equal(state.retryPromptAddendum, addendum);
    assert.equal(state.kind, 'recoveryState');
    assert.equal(state.schemaVersion, 1);
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
});

test('validation_mismatch also returns retry_with_addendum', async () => {
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'ralph-recovery-'));
  try {
    const decision = await dispatchRecovery(makeContext(tmpDir, {
      analysis: makeAnalysis({ rootCauseCategory: 'validation_mismatch', retryPromptAddendum: 'Check output format.' })
    }));
    assert.equal(decision.action, 'retry_with_addendum');
    assert.equal(decision.retryPromptAddendum, 'Check output format.');
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
});

// ---------------------------------------------------------------------------
// AC 13: dependency_missing releases claim and pauses
// ---------------------------------------------------------------------------

test('dependency_missing releases claim and returns pause when autoApplyRemediation is set', async () => {
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'ralph-recovery-'));
  try {
    let claimReleased = false;
    const decision = await dispatchRecovery(makeContext(tmpDir, {
      analysis: makeAnalysis({ rootCauseCategory: 'dependency_missing' }),
      autoApplyRemediation: ['decompose_task'],
      releaseClaim: async () => { claimReleased = true; }
    }));

    assert.equal(decision.action, 'release_claim_and_pause');
    assert.equal(decision.pauseAgent, true);
    assert.ok(claimReleased, 'releaseClaim callback should have been invoked');
    assert.equal(decision.autoApplied, true);
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
});

test('dependency_missing does NOT release claim when autoApplyRemediation is empty', async () => {
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'ralph-recovery-'));
  try {
    let claimReleased = false;
    const decision = await dispatchRecovery(makeContext(tmpDir, {
      analysis: makeAnalysis({ rootCauseCategory: 'dependency_missing' }),
      autoApplyRemediation: [],
      releaseClaim: async () => { claimReleased = true; }
    }));

    assert.equal(decision.action, 'release_claim_and_pause');
    assert.equal(decision.pauseAgent, true);
    assert.equal(claimReleased, false, 'releaseClaim should NOT be called when autoApplyRemediation is empty');
    assert.equal(decision.autoApplied, false);
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
});

// ---------------------------------------------------------------------------
// AC 14: escalate_to_operator pauses agent and emits notification
// ---------------------------------------------------------------------------

test('escalate_to_operator is triggered when maxRecoveryAttempts is exceeded', async () => {
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'ralph-recovery-'));
  try {
    const ctx = makeContext(tmpDir, {
      analysis: makeAnalysis({ rootCauseCategory: 'transient' }),
      maxRecoveryAttempts: 1,
      autoApplyRemediation: ['decompose_task']
    });

    // First attempt: within limit.
    const first = await dispatchRecovery(ctx);
    assert.equal(first.action, 'retry_with_backoff');

    // Second attempt: exceeds maxRecoveryAttempts=1 → escalate.
    let emittedMessage = '';
    const second = await dispatchRecovery({ ...ctx, emitOperatorNotification: async (msg) => { emittedMessage = msg; } });

    assert.equal(second.action, 'escalate_to_operator');
    assert.equal(second.pauseAgent, true);
    assert.ok(second.escalated);
    assert.ok(emittedMessage.length > 0, 'operator notification message should be emitted');
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
});

test('escalate_to_operator does NOT emit notification when autoApplyRemediation is empty', async () => {
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'ralph-recovery-'));
  try {
    const ctx = makeContext(tmpDir, {
      analysis: makeAnalysis({ rootCauseCategory: 'transient' }),
      maxRecoveryAttempts: 0,
      autoApplyRemediation: []
    });

    let notified = false;
    const decision = await dispatchRecovery({ ...ctx, emitOperatorNotification: async () => { notified = true; } });

    assert.equal(decision.action, 'escalate_to_operator');
    assert.equal(decision.pauseAgent, true);
    assert.equal(notified, false, 'no notification should be emitted when autoApplyRemediation is empty');
    assert.equal(decision.autoApplied, false);
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
});

// ---------------------------------------------------------------------------
// Additional coverage: task_ambiguity and environment_issue playbooks
// ---------------------------------------------------------------------------

test('task_ambiguity returns trigger_planning_pass without pausing', async () => {
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'ralph-recovery-'));
  try {
    const decision = await dispatchRecovery(makeContext(tmpDir, {
      analysis: makeAnalysis({ rootCauseCategory: 'task_ambiguity' })
    }));
    assert.equal(decision.action, 'trigger_planning_pass');
    assert.equal(decision.pauseAgent, false);
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
});

test('environment_issue returns attempt_preflight_remediation', async () => {
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'ralph-recovery-'));
  try {
    const decision = await dispatchRecovery(makeContext(tmpDir, {
      analysis: makeAnalysis({ rootCauseCategory: 'environment_issue' })
    }));
    assert.equal(decision.action, 'attempt_preflight_remediation');
    assert.equal(decision.pauseAgent, false);
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
});

// ---------------------------------------------------------------------------
// Recovery-state persistence
// ---------------------------------------------------------------------------

test('recovery-state.json is written with correct schema on first dispatch', async () => {
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'ralph-recovery-'));
  try {
    await dispatchRecovery(makeContext(tmpDir, {
      analysis: makeAnalysis({ rootCauseCategory: 'transient' })
    }));

    const stateText = await fs.readFile(getRecoveryStatePath(tmpDir, 'T1'), 'utf8');
    const state = JSON.parse(stateText);
    assert.equal(state.schemaVersion, 1);
    assert.equal(state.kind, 'recoveryState');
    assert.equal(state.taskId, 'T1');
    assert.equal(state.category, 'transient');
    assert.equal(state.attemptCount, 1);
    assert.equal(state.escalated, false);
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
});

test('getRecoveryStatePath returns expected path', () => {
  const dir = '/tmp/artifacts';
  const result = getRecoveryStatePath(dir, 'T42');
  assert.ok(result.endsWith(path.join('T42', 'recovery-state.json')));
});

// ---------------------------------------------------------------------------
// AC 5: task written to dead-letter.json after exhausting recovery attempts
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// T105 AC5–AC7: failure chain detection and systemic alert
//
// Each test uses its own tmpDir so the in-memory window is isolated per run.
// ---------------------------------------------------------------------------

test('3 failures with same category and high confidence triggers systemic alert', async () => {
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'ralph-systemic-'));
  try {
    // Dispatch three high-confidence transient failures for different tasks.
    // The systemic alert fires on the third dispatch (window hits threshold=3).
    for (const taskId of ['TA', 'TB']) {
      await dispatchRecovery(makeContext(tmpDir, {
        taskId,
        analysis: makeAnalysis({ rootCauseCategory: 'transient', confidence: 'high' })
      }));
    }
    const third = await dispatchRecovery(makeContext(tmpDir, {
      taskId: 'TC',
      analysis: makeAnalysis({ rootCauseCategory: 'transient', confidence: 'high' })
    }));

    assert.equal(third.action, 'escalate_to_operator');
    assert.equal(third.pauseAgent, true);
    assert.ok(third.escalated, 'escalated should be true for systemic alert');
    assert.ok(third.summary.includes('Systemic'), 'summary should mention systemic detection');
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
});

test('mixed categories or low-confidence failures below threshold do not trigger systemic alert', async () => {
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'ralph-systemic-'));
  try {
    // Two high-confidence transient + one low-confidence transient: total high-conf < 3
    await dispatchRecovery(makeContext(tmpDir, {
      taskId: 'TA',
      analysis: makeAnalysis({ rootCauseCategory: 'transient', confidence: 'high' })
    }));
    await dispatchRecovery(makeContext(tmpDir, {
      taskId: 'TB',
      analysis: makeAnalysis({ rootCauseCategory: 'transient', confidence: 'high' })
    }));
    const third = await dispatchRecovery(makeContext(tmpDir, {
      taskId: 'TC',
      analysis: makeAnalysis({ rootCauseCategory: 'transient', confidence: 'low' })
    }));

    // Low-confidence entry does not count: only 2 of 3 transient events are >= 0.7.
    assert.notEqual(third.action, 'escalate_to_operator',
      'should not escalate when high-confidence count < threshold');
    assert.equal(third.action, 'retry_with_backoff');

    // Also verify: three different categories with high confidence do not trigger alert.
    const tmpDir2 = await fs.mkdtemp(path.join(os.tmpdir(), 'ralph-systemic-mixed-'));
    try {
      for (const [taskId, category] of [['TA', 'transient'], ['TB', 'implementation_error'], ['TC', 'environment_issue']] as const) {
        const d = await dispatchRecovery(makeContext(tmpDir2, {
          taskId,
          analysis: makeAnalysis({ rootCauseCategory: category, confidence: 'high' })
        }));
        assert.notEqual(d.action, 'escalate_to_operator',
          `category ${category} should not trigger systemic alert alone`);
      }
    } finally {
      await fs.rm(tmpDir2, { recursive: true, force: true });
    }
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
});

test('systemic alert artifact is written to correct path with expected schema', async () => {
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'ralph-systemic-'));
  try {
    for (const taskId of ['TA', 'TB', 'TC']) {
      await dispatchRecovery(makeContext(tmpDir, {
        taskId,
        analysis: makeAnalysis({ rootCauseCategory: 'implementation_error', confidence: 'high' })
      }));
    }

    const alertPath = getSystemicAlertPath(tmpDir);
    const raw = await fs.readFile(alertPath, 'utf8');
    const alert = JSON.parse(raw) as SystemicFailureAlert;

    assert.equal(alert.schemaVersion, 1);
    assert.equal(alert.kind, 'systemicFailureAlert');
    assert.equal(alert.sharedCategory, 'implementation_error');
    assert.ok(Array.isArray(alert.affectedTaskIds) && alert.affectedTaskIds.length >= 3,
      'affectedTaskIds should include at least the 3 triggering tasks');
    assert.ok(typeof alert.recommendedOperatorAction === 'string' && alert.recommendedOperatorAction.length > 0,
      'recommendedOperatorAction should be a non-empty string');
    assert.ok(typeof alert.detectedAt === 'string' && alert.detectedAt.length > 0,
      'detectedAt should be a non-empty ISO timestamp');
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
});

// ---------------------------------------------------------------------------
// AC 5: task written to dead-letter.json after exhausting recovery attempts
// ---------------------------------------------------------------------------

test('dispatchRecovery writes dead-letter entry after exhausting max recovery attempts', async () => {
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'ralph-recovery-'));
  try {
    const dlPath = path.join(tmpDir, 'dead-letter.json');
    const capturedEntries: DeadLetterEntry[] = [];
    const analysis = makeAnalysis({ rootCauseCategory: 'transient' });
    const diagnosticHistory = [analysis];

    const ctx = makeContext(tmpDir, {
      taskId: 'T5',
      taskTitle: 'Exhausted Task',
      analysis,
      diagnosticHistory,
      maxRecoveryAttempts: 1,
      writeDeadLetterEntry: async (entry) => {
        capturedEntries.push(entry);
        // Also persist to file for round-trip verification
        const { appendDeadLetterEntry } = await import('../src/ralph/deadLetter');
        await appendDeadLetterEntry(dlPath, entry);
      }
    });

    // First attempt — within limit, no dead letter
    await dispatchRecovery(ctx);
    assert.equal(capturedEntries.length, 0, 'no dead-letter on first attempt within limit');

    // Second attempt — exceeds maxRecoveryAttempts (1), should dead-letter
    const decision = await dispatchRecovery(ctx);
    assert.equal(decision.action, 'escalate_to_operator');
    assert.equal(decision.escalated, true);
    assert.equal(capturedEntries.length, 1, 'dead-letter entry written on escalation');
    assert.equal(capturedEntries[0].taskId, 'T5');
    assert.equal(capturedEntries[0].taskTitle, 'Exhausted Task');
    assert.equal(capturedEntries[0].diagnosticHistory.length, 1);
    assert.equal(capturedEntries[0].recoveryAttemptCount, 2);

    // Verify round-trip via file
    const queue = await readDeadLetterQueue(dlPath);
    assert.equal(queue.entries.length, 1);
    assert.equal(queue.entries[0].taskId, 'T5');
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
});
