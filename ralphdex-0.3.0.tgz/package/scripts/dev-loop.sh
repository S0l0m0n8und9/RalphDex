#!/usr/bin/env bash
set -euo pipefail

npm run compile
code .
